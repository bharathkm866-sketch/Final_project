﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Final_project
{
    public partial class CustMng : Form
    {
        public CustMng()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ApplayLL a1 = new ApplayLL();
            a1.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connstr = @"Data Source=bharathkm\SQLEXPRESS;Initial Catalog=registration;Integrated Security=True;Trust Server Certificate=True";

            using (SqlConnection conn = new SqlConnection(connstr))
            {
                SqlDataAdapter sqlda = new SqlDataAdapter("select * from registration", conn);
                DataTable dt1 = new DataTable();
                sqlda.Fill(dt1);

                dataGridView1.DataSource = dt1;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string connstr = @"Data Source=bharathkm\SQLEXPRESS;Initial Catalog=registration;Integrated Security=True;Trust Server Certificate=True";

            using (SqlConnection conn = new SqlConnection(connstr))
            {
                SqlDataAdapter sqlda = new SqlDataAdapter("select * from Emo_allo", conn);
                DataTable dt2 = new DataTable();
                sqlda.Fill(dt2);

                dataGridView2.DataSource = dt2;
            }
        }
    }
}
