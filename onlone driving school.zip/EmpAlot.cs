﻿using Microsoft.Data.SqlClient;

namespace Final_project
{
    public partial class EmpAlot : Form
    {
        public EmpAlot()
        {
            InitializeComponent();
        }
        
    
        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        //Data Source=bharathkm\SQLEXPRESS;Initial Catalog=NIRMITHA;Integrated Security=True;Trust Server Certificate=True
        //Data Source=bharathkm\SQLEXPRESS;Initial Catalog=registration;Integrated Security=True;Trust Server Certificate=True
        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=bharathkm\\SQLEXPRESS;Initial Catalog=registration;Integrated Security=True;Trust Server Certificate=True");
            conn.Open();
            string insertQuery = "INSERT INTO Emo_allo VALUES (@ename,@cname,@cdate,@ctime,@place)";
            SqlCommand cmd = new SqlCommand(insertQuery, conn);
            cmd.Parameters.AddWithValue("@ename", textBox1.Text.Trim());
            cmd.Parameters.AddWithValue("@cname", textBox2.Text.Trim());
            cmd.Parameters.AddWithValue("@cdate", Convert.ToDateTime(dateTimePicker1.Text));
            cmd.Parameters.AddWithValue("ctime", comboBox2.SelectedItem.ToString());

            cmd.Parameters.AddWithValue("@place", comboBox1.SelectedItem.ToString());
            cmd.ExecuteNonQuery();
            MessageBox.Show("saved succesfully", "info", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
